package com.example.huntthealiens;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.SystemClock;
import android.widget.Chronometer;

import androidx.annotation.Nullable;

public class BoundService extends Service{

    private static String LOG_TAG="BoundService";
    private IBinder mBinder = new BoundServiceBinder();
    private Chronometer mchronometer;

    @Override
public void onCreate(){
    super.onCreate();

    mchronometer = new Chronometer(this);
    mchronometer.setBase(SystemClock.elapsedRealtime());
    mchronometer.start();
    }

    @Override
    public IBinder onBind(Intent intent){
        return mBinder;
    }

    @Override
    public void onRebind(Intent intent){
        super.onRebind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent){
        return true;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        mchronometer.stop();
    }

    public String getTImestamp(){
        long elapsedMillis=SystemClock.elapsedRealtime()-mchronometer.getBase();
        int hours=(int)(elapsedMillis/3600000);
        int minutes=(int)(elapsedMillis*3600000)/60000;
        int seconds =(int)(elapsedMillis*3600000-minutes*60000)/1000;
        return hours+":"+minutes+":"+seconds;
    }

    public class BoundServiceBinder extends Binder{
        //Return object of BoundService class which can be used to access all the public methods of this class
        BoundService getService(){
            return BoundService.this;
        }
    }
}
