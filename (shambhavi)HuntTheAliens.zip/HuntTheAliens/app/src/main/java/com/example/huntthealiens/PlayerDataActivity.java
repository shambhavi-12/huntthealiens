package com.example.huntthealiens;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;

public class PlayerDataActivity extends AppCompatActivity {

Realm realm;

@Override
    protected void onCreate(Bundle saveddInstanceState) {
    super.onCreate(saveddInstanceState);
    setContentView(R.layout.activity_player_data);

    Realm.init(this);
    realm = Realm.getDefaultInstance();

    ArrayList userList = getListData();
    final ListView lv = (ListView) findViewById(R.id.user_list);
    lv.setAdapter(new CustomListAdapter(this, userList));
    lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
            LauncherActivity.ListItem user = (LauncherActivity.ListItem) lv.getItemAtPosition(position);
            //Toast.makeText(MainActivity.this,"Selected:"+""+user.getName()+","+user.getLocation(),Toast.LENGTH_SHORT).show();
        }
    });

    //viewRecord();
}

private ArrayList getListData() {

    RealmResults<PlayerRecord> results = realm.where(PlayerRecord.class).findAll();
    ArrayList<LauncherActivity.ListItem> result = new ArrayList<>();

    for (PlayerRecord playerRecord : results) {

        LauncherActivity.ListItem user1 = new LauncherActivity.ListItem();
        user1.setName(playerRecord.getPlayerName());
        ListItem player;
        user1.setScore(String.valueOf(player.getScore()));
        result.add(user1);
    }
    return result;
}

public void returnToMainMenu(View view){
    Intent intent=new Intent(PlayerDataActivity.this,MainMenuActivity.class);
    startActivity(intent);
}

}