package com.example.huntthealiens;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import io.realm.Realm;

public class GameOverScreen extends AppCompatActivity {

    Button buttonReturnToMain;
    TextView timestampText;
    Realm realm;
    EditText playerName;
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over_screen);

        TextView scoreLabel = (TextView) findViewById(R.id.scoreLabel);
        TextView loseScore = (TextView) findViewById(R.id.scoreLose);
        TextView highScoreLabel = (TextView) findViewById(R.id.highScoreLabel);
        timestampText = (TextView) findViewById(R.id.timeStamp);
        playerName = (EditText) findViewById(R.id.playerNameEditTextView);

        buttonReturnToMain = (Button) findViewById(R.id.Wroc);

        buttonReturnToMain = (Button) findViewById(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addRecordToDatabase();
                Intent intent = new Intent(Result.this, MainMenuActivity.class);
                startActivity(intent);
                Result.this.finish();
            }
        });

        score = getIntent().getIntExtra("Score", 0);
        scoreLabel.setText("You Killed:" + score + "Aliens");
        int losescore = getIntent().getIntExtra("SCORELOSE", 0);
        loseScore.setText("You let 5 aliens go!");

        String timeStampvalue = getIntent().getStringExtra("TimeStamp");
        timestampText.setText(timeStampvalue);

        SharedPreferences settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        int highScore = settings.getInt("HIGH_SCORE", 0);

        if (score > highScore) {
            highScoreLabel.setText("High Score:" + score);

            SharedPreferences.Editor editor = settings.edit();
            editor.putInt("HIGH_SCORE", score);

            editor.commit();
        } else {
            highScoreLabel.setText("High Score:" + highScore);
        }

        Realm.init(this);
        realm = Realm.getDefaultInstance();
    }

    public void addRecordToDatabase() {
        //if(playerName.getText().toString()!=null){
        realm.beginTransactrion();

        PlayerRecord playerRecord = realm.createObject(PlayerRecord.class);
        playerRecord.setPlayerName((playerName.getText().toString()));
        playerRecord.setScore();

        realm.commitTransaction();
        // }
    }

    public void TryAgain(View view) {
        addRecordToDatabase();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    @Override
    public void onBackPressed()
    {
        superOnBackPressed();
        addRecordToDatabase();
        Intent intent = new nintent(GameOverScreen.this, MainMenuActivity.class);
        startActivity(intent);
        GameOverScreen.this.finish();
    }
}