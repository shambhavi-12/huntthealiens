package com.example.huntthealiens;

import android.app.LauncherActivity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomListAdapter extends BaseAdapter{
    private ArrayList<LauncherActivity.ListItem>listData;
    private LayoutInflater layoutInflater;

    public CustomListAdapter(Context aContext,ArrayList<LauncherActivity.ListItem>listData){
     this.listData=listData;
     layoutInflater = LayoutInflater.from(aContext);
    }

    @Override
    public int getCount(){
        return listData.size();
    }

    @Override
    public Object getItem(int position){
        return listData.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }


    @Override
    public View getView(int position, View v,ViewGroup parent){
        ViewHolder holder;
        if (v==null){
            v= layoutInflater.inflate(R.layout.list_row,null);
            holder=new ViewHolder();
            holder.uName=(TextView)v.findViewById(R.id.name);
            holder.uScore=(TextView)v.findViewById(R.id.score);

            v.setTag(holder);
        }else
            {
                holder=(ViewHolder)v.getTag();
            }
        holder.uName.setText(listData.get(position).getName());
        holder.uScore.setText(listData.get(position).getScore());

        return v;
    }
    static class ViewHolder{
        TextView uName;
        TextView uScore;
    }
}