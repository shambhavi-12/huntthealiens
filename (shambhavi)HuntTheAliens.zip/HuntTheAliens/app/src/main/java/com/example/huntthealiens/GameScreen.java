package com.example.huntthealiens;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.TextView;

import java.util.prefs.AbstractPreferences;

public class GameScreen extends AppCompatActivity
{


    CustomBoundService customBoundService;
    boolean serviceBound = false;
    String timeElapsed = "null";

    TextView mTextView;
    private Object ServiceConnection;

    @Override
    protected void onCreate(BundlesavedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);

        mTextView = (TextView)findViewById(R.id.test);
    }

    public void onEndButtonPressed(View view)
    {

        if(serviceBound)
        {
            timeElapsed=customBoundService.getTimeStamp();
            unbindService(serviceConnection);
            serviceBound = false;
        }
        mTextView.setText(timeElapsed);

        Intent intent = new Intent(this,GameOverScreen.class);
        intent.putExtra("time",timeElapsed);
        startActivity(intent);
    }

    public void onFireButtonPressed(View view)
    {
        Intent intent = new Intent(getApplicationContext(),CustomBoundService.class);
        bindService(intent,serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection serviceConnection = new ServiceConnection()
    {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service)
        {
            CustomBoundService.CustomBinder bind = (CustomBoundService.CustomBinder) service;
            serviceBound = true;
            customBoundService = bind.getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name)
        {
            serviceBound = false;
        }
    };

    @Override
    protected void onStart()
    {
        super.onStart();
    }

    @Override
    protected void onStop()
    {
        super.onStop();


        if(serviceBound)
        {
            unbindService((android.content.ServiceConnection) ServiceConnection);
            serviceBound=false;
        }
    }
}
